I choose prosperLoanData set.

Conclusion:

1. Univariate Exploration

    - LoanStatus:

        1-number of completed loan=38074.

        2-number of loans are in current pending state=56576.

        3-number of loans have past due(1 to 15 days)=806.

        4-number of loans chargedoff=11992.

        5-number of loans are defaulted=5018

2.Bivariate Analysis:-

    - ProsperRating (Alpha) vs IsBorrowerHomeowner:-

         -Home improvement for all even if you do not have home.


3.Multivariate Analysis:-

    - LoanStatus Vs BorrowerAPR VS EmploymentStatus:-

           -The employees receive fewer loans than the unemployed
        b. Borrower APR vs Status of Loan
            
            1-Completed, Current, Cancelled and Final Payment in Progress have the lowest BorrowerARP.
            
            2-Charged off loans and defaulted have the highest median of borrower rate.
            
    3.Multivariate Analysis
    
           1-The employees receive fewer loans than the unemployed